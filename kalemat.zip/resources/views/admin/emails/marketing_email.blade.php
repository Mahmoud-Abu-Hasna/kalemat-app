@extends('admin.emails.layout')
@section('content')

    <tr>
        <td>
            {!! $mail_message !!}
        </td>
    </tr>

@endsection
