<?php /* C:\wamp64\www\market_coupuns\resources\views/admin/categories/quotes.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">

                    <div class="panel-heading">
                        <span style="font-size: 20px;color:#4dc0b5;"><strong><?php echo e($category_name); ?> Sub-Categories</strong></span>
                        <div style="float: right;margin-top: -8px !important;margin-right: 10px;" class="row">
                            <a href="<?php echo e(route('admin.categories')); ?>"
                                    class="mx-sm-3 mb-2 btn btn-outline-info btn-sm">Back
                            </a>
                            <form class="mx-sm-3 mb-2 form-inline">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-search"></i></div>
                                        </div>
                                        <input type="text" name="name" id="name" placeholder="Search"
                                               class="form-control form-control-sm"></div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="panel-body">


                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Choices</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th scope="row"><?php echo e($sub_category->id); ?></th>
                                    <td class="name"><?php echo e($sub_category->name); ?></td>
                                    <td>
                                        <button class="btn btn-danger btn-sm delete-button" data-toggle="tooltip"
                                                data-placement="bottom" title="Delete Category"
                                                data-id="<?php echo e($sub_category->id); ?>"><i class="fa fa-times"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>

                                    <td colspan="6">No Sub-Categories are Provided</td>

                                </tr>

                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php if(count($sub_categories)): ?>
                            <?php echo e($sub_categories->links()); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        $(document).ready(function () {

            $(document).on('click', '.delete-button', function (e) {
                e.preventDefault();
                var id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            type: "post",
                            url: "<?php echo e(route('admin.sub-categories.delete')); ?>",
                            data: {id: id},
                            cache: false,
                            success: function (data, textStatus, xhr) {
                                if (data.error) {
                                    Swal.fire({
                                        position: 'center',
                                        type: 'error',
                                        title: 'Error!',
                                        text: data.error,
                                        showConfirmButton: false,
                                        timer: 2000
                                    });
                                    $('.swal2-container').css('z-index', '30000');
                                } else {
                                    if (xhr.status == 200) {
                                        Swal.fire({
                                            position: 'center',
                                            type: 'success',
                                            title: 'Success!',
                                            text: data.success,
                                            showConfirmButton: false,
                                            timer: 2000
                                        });
                                        $('.swal2-container').css('z-index', '30000');
                                        setTimeout(function () {
                                            location.reload();
                                        }, 2500);
                                    }
                                }

                            },

                        });
                    }
                })
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>