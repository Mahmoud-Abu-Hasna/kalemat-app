<?php /* C:\wamp64\www\market_coupuns\resources\views/admin/quotes/quotes.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">

                    <div class="panel-heading">
                        <span style="font-size: 20px;color:#4dc0b5;"><strong>Products</strong></span>
                        <div style="float: right;margin-top: -8px !important;margin-right: 10px;" class="row">
                            <button href="#addProductCsv" data-toggle="modal"
                                    class="mx-sm-3 mb-2 btn btn-outline-info btn-sm">Add Products from CSV FILE
                            </button>
                            <form class="mx-sm-3 mb-2 form-inline">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-search"></i></div>
                                        </div>
                                        <input type="text" name="name" id="name" placeholder="Search"
                                               class="form-control form-control-sm"></div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="panel-body">


                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Commission Rate</th>
                                <th>Discount</th>
                                <th>End Date</th>
                                <th>Choices</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th scope="row"><?php echo e($product->id); ?></th>
                                    <td class="title"><?php echo e($product->title); ?></td>
                                    <td class="commission-rate"><?php echo e($product->commission_rate); ?></td>
                                    <td class="discount"><?php echo e($product->discount); ?></td>
                                    <td class="end-date"><?php echo e($product->end_date); ?></td>
                                    <td>
                                        <button class="btn btn-danger btn-sm delete-button" data-toggle="tooltip"
                                                data-placement="bottom" title="Delete Product"
                                                data-id="<?php echo e($product->id); ?>"><i class="fa fa-times"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>

                                    <td colspan="6">No Products are Provided</td>

                                </tr>

                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php if(count($products)): ?>
                            <?php echo e($products->links()); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="addProductCsv" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">


                <form class="form-horizontal" method="POST" action="<?php echo e(route('admin.addFromCSV')); ?>"
                      data-parsley-validate enctype="multipart/form-data">
                    <div class="modal-header">
                        <h4 class="modal-title">Add Products from CSV</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>(available,categoryId,commissionRate,currencyId,discount,endDate<br>,id,image,modified_time,name,oldprice,price,title,type,url,deleted)
                        </p>

                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label class="control-label">Please,choose .csv file contains these columns</label>

                            <div>
                                <input id="add_product_file" type="file" accept=".csv"
                                       class="form-control <?php echo e($errors->has('add_product_file') ? ' is-invalid' : ''); ?>"
                                       name="add_product_file" required autofocus>

                                <?php if($errors->has('add_product_file')): ?>
                                    <span class="invalid-feedback">
                                          <strong><?php echo e($errors->first('add_product_file')); ?></strong>
                                      </span>
                                <?php endif; ?>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">
                            Add
                        </button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    </div>
                </form>


            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        $(document).ready(function () {

            $(document).on('click', '.delete-button', function (e) {
                e.preventDefault();
                var id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            type: "post",
                            url: "<?php echo e(route('admin.quotes.delete')); ?>",
                            data: {id: id},
                            cache: false,
                            success: function (data, textStatus, xhr) {
                                if (data.error) {
                                    Swal.fire({
                                        position: 'center',
                                        type: 'error',
                                        title: 'Error!',
                                        text: data.error,
                                        showConfirmButton: false,
                                        timer: 2000
                                    });
                                    $('.swal2-container').css('z-index', '30000');
                                } else {
                                    if (xhr.status == 200) {
                                        Swal.fire({
                                            position: 'center',
                                            type: 'success',
                                            title: 'Success!',
                                            text: data.success,
                                            showConfirmButton: false,
                                            timer: 2000
                                        });
                                        $('.swal2-container').css('z-index', '30000');
                                        setTimeout(function () {
                                            location.reload();
                                        }, 2500);
                                    }
                                }

                            },

                        });
                    }
                })
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>