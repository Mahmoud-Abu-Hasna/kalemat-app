<?php /* C:\wamp64\www\market_coupuns\resources\views/admin/home.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                            <div class="row text-center">
                                <div class="col">
                                    <div class="counter">
                                        <i class="fa fa-code fa-2x"></i>
                                        <h2 class="timer count-title count-number" data-to="<?php echo e($link_visits); ?>" data-speed="1500"></h2>
                                        <p class="count-text ">Link Clicks</p>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="counter">
                                        <i class="fa fa-user fa-2x"></i>
                                        <h2 class="timer count-title count-number" data-to="<?php echo e($visits); ?>" data-speed="1500"></h2>
                                        <p class="count-text ">Total Visits</p>
                                    </div>
                                </div>
                            </div>
                           <br>
                           <br>
                           <br>
                        <div class="row text-center">

                                <table class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Commission Rate</th>
                                        <th>Discount</th>
                                        <th>End Date</th>
                                        <th>Visits</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $top_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <th scope="row"><?php echo e($product->id); ?></th>
                                            <td class="title full-title" data-toggle="tooltip" data-title="<?php echo e($product->title); ?>"><?php echo e(str_limit($product->title,20)); ?></td>
                                            <td class="commission-rate"><?php echo e($product->commission_rate); ?></td>
                                            <td class="discount"><?php echo e($product->discount); ?></td>
                                            <td class="end-date"><?php echo e($product->end_date); ?></td>
                                            <td class="visits"><?php echo e($product->visits); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>

                                            <td colspan="6">No Products are Provided</td>

                                        </tr>

                                    <?php endif; ?>
                                    </tbody>
                                </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <link href="<?php echo e(asset('css/counter.css')); ?>" rel="stylesheet">
    <script  type="text/javascript" rel="script" src="<?php echo e(asset('js/counter.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {

            $(".full-title").tooltip();


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>