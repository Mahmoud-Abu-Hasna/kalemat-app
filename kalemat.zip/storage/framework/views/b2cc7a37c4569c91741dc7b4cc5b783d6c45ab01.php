<?php /* C:\wamp64\www\market_coupuns\resources\views/admin/emails/marketing_email.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <tr>
        <td>
            <?php echo $mail_message; ?>

        </td>
    </tr>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.emails.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>