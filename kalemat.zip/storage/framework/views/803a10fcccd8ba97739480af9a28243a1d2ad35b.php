<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        Dashboard
                        <button type="button" style="float: right;" class="btn btn-info btn-sm full-title" data-toggle="modal" data-target="#addNotification" data-toggle="tooltip" data-title="Notify Users"><i class="fa fa-phone"></i></button>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                            <div class="row text-center">
                                <div class="col">
                                    <div class="counter">
                                        <i class="fa fa-code fa-2x"></i>
                                        <h2 class="timer count-title count-number" data-to="<?php echo e($quotes); ?>" data-speed="1500"></h2>
                                        <p class="count-text ">Quotes</p>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="counter">
                                        <i class="fa fa-user fa-2x"></i>
                                        <h2 class="timer count-title count-number" data-to="<?php echo e($users); ?>" data-speed="1500"></h2>
                                        <p class="count-text ">Users</p>
                                    </div>
                                </div>
                            </div>
                           <br>
                           <br>
                           <br>
                        <div class="row text-center">

                                <table class="table table-bordered table-hover table-responsive-lg">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Quote Ar</th>
                                        <th>Quote En</th>
                                        <th>Category</th>
                                        <th>Favorites</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $fav_quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <th scope="row"><?php echo e($quote->id); ?></th>
                                            <td class="quote_ar full-title" data-toggle="tooltip" data-title="<?php echo e($quote->quote_ar); ?>"><?php echo e(str_limit($quote->quote_ar,20)); ?></td>
                                            <td class="quote_en full-title" data-toggle="tooltip" data-title="<?php echo e($quote->quote_en); ?>"><?php echo e(str_limit($quote->quote_en,20)); ?></td>
                                            <td class="name_ar"><?php echo e($quote->category->name_ar); ?></td>
                                            <td class="fave"><?php echo e($quote->fave); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>

                                            <td colspan="5">No Quotes are Provided</td>

                                        </tr>

                                    <?php endif; ?>
                                    </tbody>
                                </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="addNotification" class="modal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Send Notifications</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('notify')); ?>">
                    <div class="modal-body">

                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="title_ar" class="col-form-label">Title AR:</label>
                            <input dir="rtl" type="text" name="title_ar" class="form-control" id="title_ar" value="<?php echo e(old('title_ar')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="title_en" class="col-form-label">Title EN:</label>
                            <input type="text" name="title_en" class="form-control" id="title_en"  value="<?php echo e(old('title_en')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="body_ar" class="col-form-label">Body AR:</label>
                            <input  dir="rtl" type="text" name="body_ar" class="form-control" id="body_ar" value="<?php echo e(old('body_ar')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="body_en" class="col-form-label">Body EN:</label>
                            <input type="text" name="body_en" class="form-control" id="body_en"  value="<?php echo e(old('body_en')); ?>" required>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" >Save</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <link href="<?php echo e(asset('css/counter.css')); ?>" rel="stylesheet">
    <script  type="text/javascript" rel="script" src="<?php echo e(asset('js/counter.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\wamp\www\kalemat\resources\views/admin/home.blade.php */ ?>